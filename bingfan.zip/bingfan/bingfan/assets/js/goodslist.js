$(function(){
	console.log("hello");
                $('.M-box1').pagination({
                    totalData:100,
                    showData:5,
                    coping:true，
                    homePage:'首页'，
                    endPage:"末页"，
                    prevContent:"上页"，
                    nextContent:'下页',
                    
                
                })

              
})