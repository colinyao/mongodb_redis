$(document).ready(function() {
  
  var magnifierConfig = {
    magnifier : "#magnifier1",//最外层的大容器
    width : 400,//承载容器宽
    height : 400,//承载容器高
    moveWidth : null,//如果设置了移动盒子的宽度，则不计算缩放比例
    zoom : 5//缩放比例
  };

  var _magnifier = magnifier(magnifierConfig);

  /*magnifier的内置函数调用*/
  /*
    //设置magnifier函数的index属性
    _magnifier.setIndex(1);

    //重新载入主图,根据magnifier函数的index属性
    _magnifier.eqImg();
  */
  // var mySwiper=new Swiper(".swiper-container",{
  //   direction:"vertical",
  //   loop:true,
  //   nextButton: '.swiper-button-next',
  //   prevButton: '.swiper-button-prev',
  //   loop:true,
  //   height:110
  // })
  // $(".swiper-button-prev").click(function(){
  //   mySwiper.slidePrev(),
  //   console.log("hello")
  // })
  // $(".swiper-button-next").click(function(){
  //   mySwiper.slideNext();
  // })




  $('#list').bxSlider({
    mode:'vertical',
    displaySlideQty:5,
    minSlides: 5,
    pager:false,

  });



    
});